document.getElementById("submit").addEventListener(
  "click",
  function () {
    alert("Success!");
  },
  false
);
